import numpy as np
import sys
import matplotlib.pyplot as plt
import imageio
from scipy.signal import hilbert
from scipy.signal import savgol_filter
import emd


from matplotlib import rcParams
rcParams.update({'figure.autolayout': True})
 
# Enabling using LaTex for making labels pretty, not really necessary
from matplotlib import rc
rc('text', usetex=True)

# top and bottom y-values 
ybot = -0.15
ytop = 0.15
#ybot = -0.45
#ytop = -0.2
#ybot = -0.9
#ytop = -0.4

# left and right x-values
xl = -500
xr = 500
#xl = -100.0
#xr = 100.0
#xl = -40.0
#xr = 80.0
#xl = -200
#xr = 300

n_init = int(input("Enter initial frame number: "))
n_final = int(input("Enter final frame number: "))
inc = int(input("step size in frame number: "))
i=n_init
#dir = './case16/isopycnals_rho_m0p25/'
dir = './isopycnals_rho_m0p25/'
#dir = './case12_res5/isopycnals_rho_m0p25/'
time_int = 20
#dir = './case_U0p3_a04_w0p9_res5_longer_domain/isopycnals_rho_0p25/'
#dir = './case_U0p3_a042_w0p9_res5_longer_domain/isopycnals_rho_0p25/'
#dir = './case12_res6_more_saves/isopycnals_rho_m0p25/'
#time_int = 2

#dir = './case_U0p365_am025_w2p5_res6_more_saves/isopycnals_rho_0p25/'
#time_int = 2

#dir = './case_U0p365_a05_w1_res6/isopycnals_rho_0p25/'
#time_int = 2

breather1_pos = []
times1 = []



while i<=int(n_final):
    print("Doing frame ", i)
# use this to create the changes
    datafile = dir + 'isopycnal_time' + str(i)
    status2 = np.loadtxt(datafile)
    x1 = status2[:,0]
    eta1 = status2[:,1]

#    timestamps = dir + 'time' + str(i)
#    times = np.loadtxt(timestamps)
#    time = times[0]
    
    
    # plot size
    plt.figure(figsize=(11, 4), dpi=80)

    # plots the bathymetry
#    plt.plot(xbot1,ybot+(zbot1 - zbot1[0])*0.2*(ytop-ybot)/(zbot1[nb-1] - zbot1[0]), c='k')
    # creates the background
#    plt.plot(xl+0.1*(xr-xl),ybot+0.9*(ytop-ybot), c='r')
    # creates the changes in the blue line
    eta1 -= eta1[0]
    analytic_signal = hilbert(eta1)
    
    envelope = np.abs(analytic_signal)
    envelope_filtered = savgol_filter(envelope, window_length = 1001, polyorder = 2) 
   
    upper_envelope = envelope_filtered
    bottom_envelope = -upper_envelope
    
    plt.plot(x1, upper_envelope, 'k')
    plt.plot(x1, bottom_envelope, 'k')
    
    # creates counter which is 0 when we want to start tracking breather speed
    init_breather_frame = 226
    j = i-init_breather_frame

    # moves index bounds between which we search for breather peak at each frame  
    init_breather_left = 31250
    init_breather_right = 32500

    index_rate = 14

    breather_left = init_breather_left - index_rate*j
    breather_right = init_breather_right - index_rate*j

    plt.plot(x1[breather_left], upper_envelope[breather_left], marker='o') 
    plt.plot(x1[breather_right], upper_envelope[breather_right], marker='o')
    
    # search for maximum between bounds 

    envelope_max = 0
    index = breather_left

    for x in range(breather_left, breather_right):
    	if upper_envelope[x] > envelope_max:
        	envelope_max = upper_envelope[x]
        	index = x
    plt.plot(x1[index], envelope_max, marker='o') 

    # append position of breather peak to position array

    breather1_pos.append(x1[index])
        

    #plt.plot(x1, eta1, c='k')

    # sets x = 0 line for measuring
#    plt.axhline(0, c='k', ls='-', lw=1.2)

    # setting up the x and y bounds and the grid layout
    plt.ylim(ybot,ytop)
    plt.xlim(xl,xr)
    plt.grid()
    time = time_int*i

    times1.append(time)

    time_string = 't = '+str(time)
    plt.text(xl + 0.04*(xr-xl), ybot+0.9*(ytop-ybot), time_string)
    plt.xlabel(r'$x$', fontsize='14')
    plt.ylabel(r'$z$', fontsize='14')
#    plt.title('surface baroclinic current', fontsize='14')

#
#    plt.legend()
#    plt.savefig('./Frames/frame'+str(i)+'.png', format="png")  
    plt.savefig('./Frames/frame'+str(i)+'.png', format="png")  
#    plt.show()
    i += inc
    plt.close()




# from here starts the code for creating GIF
from PIL import Image, ImageDraw

images = []
print("Creating animation from frames")

for i in range(n_init, int(n_final)+1, inc):
#    print("i = ", i)
#    images.append(Image.open('./Frames/frame'+str(i)+'.png'))
    tmp = Image.open('./Frames/frame'+str(i)+'.png')
    images.append(tmp)
    tmp.load()



plt.plot(times1,breather1_pos , 'k')
plt.xlabel(r'$t$', fontsize='14')
plt.ylabel(r'$x(t)$', fontsize='14')
plt.savefig('x_vs_t.png' , format = 'png')
plt.close()

# finds velocity of breather from position

breather1_speed = np.gradient(breather1_pos, times1)

plt.plot(times1, breather1_speed, 'k')
plt.xlabel(r'$t$', fontsize='14')
plt.ylabel(r'$v(t)$', fontsize='14')
plt.savefig('v_vs_t.png' , format = 'png')
plt.close()

# averages every 20 time steps (TODO: messy needs to be cleaned up/generalized)

cnt = 0
v_avg = []
t_avg = []


while cnt < 710:
    if cnt % 20 == 0:
        next_20 = []
        for cnt_1 in range(0, 20):
            if cnt + cnt_1 < 710:
                next_20.append(breather1_speed[cnt + cnt_1])
        average = sum(next_20)/len(next_20)
        v_avg.append(average)
        t_avg.append(times1[cnt+10])
    cnt +=1     

plt.plot(t_avg, v_avg, 'k')
plt.xlabel(r'$t$', fontsize='14')
plt.ylabel(r'$v(t), averaged$', fontsize='14')
plt.savefig('v_avg_vs_t.png' , format = 'png')
plt.close()


#images[0].save('./Frames/breather_interaction.gif',
#images[0].save('./Frames/breather_interaction.mp4',
#               save_all=True, append_images=images[1:], optimize=False, duration=50, loop=0)
#               save_all=True, append_images=images[1:], optimize=False, fps=120, loop=0)
imageio.mimsave('./Frames/breather_interaction.gif', images, fps = 10)
imageio.mimsave('./Frames/breather_interaction.mp4', images, fps = 120)
